/**
 * Created by hxsd on 2016/7/28.
 */
// 注册一个控制器，负责商品数据绑定
angular.module("myapp")
    .constant("activeClass", "btn-primary")  // 声明一个常量,需要依赖注入到控制器中
    .controller("productListController", function ($scope, activeClass, shopCart) {
        // 声明一个变量，保存当前用户选中的商品类别
        $scope.selectedCategory = null;

        // 用户单击商品类别的响应函数
        $scope.selectCategory = function (category) {
            // 存储当前选中的商品类别
            $scope.selectedCategory = category;
        };

        // 过滤函数
        $scope.showByCategory = function (product) {
            // 要么用户选择的是“首页”，显示所有商品
            // 要么用户选择某个类别，属于该类别的product才显示
            return $scope.selectedCategory == null || $scope.selectedCategory == product.category;
        };

        // 返回高亮颜色类
        $scope.getActiveClass = function (category) {
            return category == $scope.selectedCategory ? activeClass : "";
        };

        // 分页数据
        $scope.currentPage = 1;     // 当前显示的页码
        $scope.pageSize = 3;        // 页面大小：每页显示的商品数量

        // 选择分页
        $scope.selectPage = function (page) {
            $scope.currentPage = page;
        };

        // 高亮分页导航按钮
        $scope.getActiveNavClass = function (page) {
            return page == $scope.currentPage ? activeClass : "";
        };

        // 添加购物车的响应函数
        $scope.addToCart = function(product){
            shopCart.add(product);  // 将商品加入购物车
        };
    });