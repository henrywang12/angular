app.controller('indexController', ['$scope', '$route', function($scope, $route) {

	// 所有动画特效列表
    $scope.effects = [
        {name: 'Slide', className: 'slide'},
        {name: 'Slidedown', className: 'slidedown'},
        {name: 'Slideup', className: 'slideup'},
        {name: 'Pop in/out', className: 'pop'},
        {name: 'Fade in/out', className: 'fade'},
        {name: 'Flip', className: 'flip'},
		{name: 'Rotate', className: 'rotate'},
		{name: 'Slide + Pop in', className: 'slide-pop'}
    ];

	// 默认为第一个特效
	$scope.effect = $scope.effects[0].className;

	// 当前菜单选项
	$scope.isActive = function(path) {
		if ($route.current && $route.current.regexp) {
			return $route.current.regexp.test(path);
		}
		return false;
	};
}]);