app.controller('pageController', ['$scope', '$location', '$routeParams', '$http', function ($scope, $location, $routeParams, $http) {

    $scope.pageId = $routeParams.pageId || 1;

    $scope.nextPage = function () {
        $scope.pageId = (++$scope.pageId % 4) || 1;
        $location.path("/page/" + $scope.pageId);
    };

    // 默认pageClass值为"page-1"
    $scope.pageClass = 'page-' + $scope.pageId;

    // 对于New York页面，获得当前天气预报
    if (parseInt($routeParams.pageId) === 2) {
    //if (+$routeParams.pageId === 2) {
        var url = [
            'https://api.forecast.io/forecast',
            'b203fbb200830c93e75ba5a49bde0b1b',
            '40.67,-73.94',
            '?callback=JSON_CALLBACK'
        ].join('/');

        $http.jsonp(url).success(function (data) {
            $scope.weather = data;
            window.weather = data;
        });
    }
}]);